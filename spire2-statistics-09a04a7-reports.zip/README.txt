Slay the Spire II progression statistics — accepted build 09a04a7

Extract this archive and open index.html in a web browser.
Keep the report folders next to index.html. No server or internet connection is needed.
The four reports include interactive filters, PNG charts, and CSV/JSON exports.

Scope: original TeraSpire2.yaml, one slot, five characters, 1,000 seeds per version.
The baseline is the exact release 1.1.2 artifact identified in manifest.json.
The accepted source revision is 09a04a7169407158c08017f9eb74a9d6dbb51871.
All current-world runs use new logic. Floor, gold, potion and shop checks are enabled.
These statistics do not measure the floorless fallback, gameplay win rates, or general fuzz reliability.
Characters in a seed are correlated; 5,000 character observations are not 5,000 independent seeds.

Share this reports ZIP for reading. For custom queries, also share the separate data ZIP.
That archive contains results.sqlite, converted power data, frozen inputs and analysis scripts.
See progression_stats.md in the data archive for sphere definitions, database schema and SQL examples.

Suggested caption:
Slay the Spire II APWorld logic comparison: release 1.1.2 versus accepted build 09a04a7.
1,000 seeds per version using one fixed five-character YAML. The reports cover Ancient,
starter-card/relic, Smith and Rest availability, support combinations, and power at first
logical access. These are logic statistics, not measured gameplay difficulty or win rates.
